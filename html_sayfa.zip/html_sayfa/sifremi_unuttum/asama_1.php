<?php if(!defined("WM_HTML_KONTROL")){ die("Buraya giriş izniniz yoktur."); exit;} ?>
<style>.content{background: url(https://i.hizliresim.com/9azaZo.png) center center no-repeat;}</style>
<div class="login-page">
<div class="form">
<br>
<h1>Şifremi Unuttum</h1>
<form action="javascript:;" id="sifremi_unuttum" method="post" variable="sifremiunuttum" class="login-form">
<input type="hidden" name="sifre_unuttum_token" value="<?=$ayar->sessionid;?>">
<p class="input-label">Kullanıcı adınız:</p>
<input id="login" placeholder="Kullanıcı adınızı giriniz" spellcheck="false" name="username" type="text" autocomplete="off" >
<br>
<p class="input-label">Email Adresi:</p>
<input id="login" placeholder="Email Adresinizi Yazın" spellcheck="false" name="eposta" type="text" autocomplete="off">
<br>
<div><div><td align="center">
		<img src="<?=WMcaptcha;?>" id="captcha_code" /> <a href="javascript:;" onClick="refreshCaptcha();"><img src="<?=$ayar->WMimg;?>refresh.png" /></a></td></div></div>

<br>
<p class="input-label">Robot olmadığınızı doğrulayın:</p>
<input placeholder="4 Haneli Kodu Yazınız" maxlength="4" name="captcha_code" type="text" autocomplete="off">
 <div class="mt-1">
	<button class="g-recaptcha btn btn-giris" type="submit" name="sifre_unuttum" value="Gönder">Gönder</button>
<p class="message mb-0 mt-1">... veya anasayfa'ya <a href="index.php">geri</a> dön</p>
</div>
</form>
</div>
</div>



