<?php if(!defined("WM_HTML_KONTROL")){ die("Buraya giriş izniniz yoktur."); exit;} ?>

<table cellspacing="5" cellpadding="5" height="30" class="birtablo">
<tr>
<th width="184" class="topLine">Başvuru Durumu :</th>
<td width="495" class="tdunkel"><?=$durum;?></td>
</tr>

</table>

<div style="margin-bottom:15px;"></div>
