<?php if(!defined("WM_HTML_KONTROL")){ die("Buraya giriş izniniz yoktur."); exit;} ?>

<p><strong>BİLGİ ! </strong> Göndere Tıkladığınızda sistem tarafından yeni şifre oluşturulup emailinize gönderilir. </p>

<form action="javascript:;" id="epgonderSifremiunuttum" method="post">
<input name="sifre_degistir" type="submit" value="Gönder" />

</form>
