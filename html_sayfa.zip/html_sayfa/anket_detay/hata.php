<div class="alert alert-danger" id="danger">
    <a class="close" href="javascript:;" onClick="document.getElementById('danger').setAttribute('style','display:none;');">×</a>
    <strong>Hata !</strong> Oy vermeniz için öncelikle üye girişi yapmalısınız. !
</div>

</center>
