<?php if(!defined("WM_HTML_KONTROL")){ die("Buraya giriş izniniz yoktur."); exit;} ?>
<a href="oyuncu-siralamasi" class="btn btn-giris pull-right">Oyuncu Sıralaması</a>
<div class="panel-body no-padding">
			
					<table class="table table-siralama">
					<thead>
						<tr>
							<td>#</td>
							<td style="text-align:left;">Lonca Adı</td>
							<td class="hidden-xs">Level</td>   
							<td class="hidden-xs">Puan</td>
							<td>Bayrak</td>
							<td class="hidden-xs">Üyeler</td>
							<td class="hidden-xs">Lider</td>

						</tr>
					</thead>
					<tbody><?php 
						$i = $limit;
	foreach($query as $row){
	$i++;
	$uyeler = $odb->prepare("SELECT COUNT(guild_member.pid) AS COUNT FROM player.guild_member WHERE guild_id = ?");
	$uyeler->execute(array($row["id"]));
	$uyeler = $uyeler->fetchColumn();
	?>
	
						<tr>
							<td><?=$i;?></td>
							<td style="text-align:left;"><?=$row["name"];?></td>
							<td class="hidden-xs"><?=$row["level"];?></td>
							<td class="hidden-xs"><?=$row["ladder_point"];?></td>
							<td><img src="<?=$ayar->WMimg.'bayrak/'.$row["empire"];?>.jpg"></td>
							<td class="hidden-xs"><?=$uyeler;?></td>
							<td class="hidden-xs"><?=$row["lider"];?></td>

						</tr>

	<?php 
	}
	?>
					</tbody>
					</table>
					<center>
					<div class="sayfalar">
<?php

$tema->sayfala("lonca-siralamasi?isim=$isim&sayfa=", $sayfa, $sayfada, $toplam_sayfa);

?>

</div>

					</div>