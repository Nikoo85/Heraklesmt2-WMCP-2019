<?php if(!defined("WM_HTML_KONTROL")){ die("Buraya giriş izniniz yoktur."); exit;} ?>
<a href="lonca-siralamasi" class="btn btn-giris pull-right">Lonca Sıralaması</a>
<div class="panel-body no-padding">
			
					<table class="table table-siralama">
					<thead>
						<tr>
							<td>#</td>
							<td style="text-align:left;">Karakter Adı</td>
							<td class="hidden-xs">Seviye</td>
							<td>Sınıf</td>
							<td class="hidden-xs">Bayrak</td>
							<td class="hidden-xs">Lonca</td>
							<td class="hidden-xs">Durum</td>
						</tr>
					</thead>
					<tbody>
					
						<?php 
	$i = $limit;
	foreach($query as $row){
	$i++;
	?>
						<tr>
							<td><?=$i;?></td>
							<td style="text-align:left;"><?=$row["name"];?>  </td>
							<td class="hidden-xs"><?=$row["level"];?></td>
							<td><img src="<?=$ayar->WMimg.'karekterler/'.$row["job"];?>.png" border="0" width="32"></td>
							<td class="hidden-xs"><img src="<?=$ayar->WMimg.'bayrak/'.$row["empire"];?>.jpg"></td>
							<td class="hidden-xs"><?=($row["lonca"] == "") ? '<span style="color:red">Yok<span></span>' : '<a href="lonca/'.$row["lonca"].'">'.$row["lonca"].'</a>';?></span></td>
							<td class="hidden-xs"><?=$vt->online_kontrol($row["name"]);?></td>
						</tr>
						
	<?php 
	}
	?>
						
					</tbody>
					</table>
					<center>
					<div class="sayfalar">
<?php

$tema->sayfala("oyuncu-siralamasi?isim=$isim&karakter=$karakter&sayfa=", $sayfa, $sayfada, $toplam_sayfa);

?>

</div>		</div>