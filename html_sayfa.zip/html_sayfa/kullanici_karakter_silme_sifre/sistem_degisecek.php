<?php if(!defined("WM_HTML_KONTROL")){ die("Buraya giriş izniniz yoktur."); exit;} ?>

<div class="alert alert-warning"><strong>BİLGİ ! </strong> Şifreniz sistem tarafından değiştirilip mail adresinize yollancaktır. Yollamak için aşağıdaki gönder butonuna basınız.</div>

<form action="javascript:;" id="karaktersilmesifre" variable="sistemdegis" method="post">
<a href="kullanici"><input type="button" value="K. Paneline Dön"></a>
<input name="karakter_sifre_degistir_2" type="submit" value="Gönder" />

</form>
