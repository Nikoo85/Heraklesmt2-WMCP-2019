<?php if(!defined("WM_HTML_KONTROL")){ die("Buraya giriş izniniz yoktur."); exit;} ?>

<div class="alert alert-warning"><strong>BİLGİ ! </strong>Karakter Silme Şifrenizi değiştirmek için, gönder butonuna tıkladıktan sonra e-postanıza gelen linke tıklamalısınız. </div>

<form action="javascript:;" id="karaktersilmesifre" variable="mailgonder" method="post">
<a href="kullanici"><input type="button" value="K. Paneline Dön"></a>
<input name="karakter_sifre_degistir_1" type="submit" value="Gönder" />

</form>
