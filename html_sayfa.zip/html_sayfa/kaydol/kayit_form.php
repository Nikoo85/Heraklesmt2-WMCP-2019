<?php if(!defined("WM_HTML_KONTROL")){ die("Buraya giriş izniniz yoktur."); exit;} ?>
<style>.content{background: url(https://i.hizliresim.com/9azaZo.png) center center no-repeat;}</style>
<div class="login-page">
<div class="form">
<br>
<script>
function refreshCaptcha() {
	$("img#captcha_code").attr('src','<?=WMcaptcha;?>');
}
</script>
<h1>Kayıt Ol</h1>
<form id="kaydol" method="post" class="login-form" action="javascript:;">
<input type="hidden" name="kayit_token" value="<?=$ayar->sessionid;?>">

<p align="center" class="input-label">5-16 Karakter Uzunluğunda Kullanıcı Adı:</p>
<input id="login" placeholder="Kullanıcı Adı" spellcheck="false" name="username" type="text" value="" autocomplete="off">
<p class="input-label">6-24 karakter uzunluğunda parola:</p>
<input placeholder="Parola" class="half-col-left" name="pass" type="password" value="" maxlength="16">
<input placeholder="Parola Tekrarı" class="half-col-right" name="pass_retry" type="password" value="" maxlength="16">
<p class="input-label">Hesabınızın E-Posta Adresi:</p>
<input placeholder="E-Posta Adresi" spellcheck="false" name="eposta" type="text" value="" autocomplete="off">
<p class="input-label">Adınız - Soyadınız:</p>
<input placeholder="Lütfen isim ve soyisminizi yazın" spellcheck="false" name="real_name" type="text" value="" autocomplete="off">
<p class="input-label">Karakter silme kodunuz:</p>
<input placeholder="Karakter Silme Kodu" spellcheck="false" name="social_id" type="text" value="" maxlength="7" size="7" placeholder="" autocomplete="off">
<p class="input-label">Hesap güvenliği için telefon numaranız:</p>
<input placeholder="Telefon Numaranız" spellcheck="false" name="phone_number" type="text" value="" maxlength="10" autocomplete="off">
<br>
<br>
<img src="<?=WMcaptcha;?>" id="captcha_code" /> <a href="javascript:;" onClick="refreshCaptcha();"><img src="<?=$ayar->WMimg;?>refresh.png" /></a>
<br>
<p class="input-label">Robot olmadığınızı doğrulayın:</p>
<input placeholder="4 Haneli Kodu Yazınız" maxlength="4" name="captcha_code" type="text" autocomplete="off">
<br>
<div class="terms mb-2">
<input type="checkbox" name="sozlesme" id="checkbox" value="1" checked style="float:none; margin:0; padding:0; height: 15px;">
<label for="checkbox">
<strong><a href="<?=$WMclass->ayar("base");?>uyelik_sozlesmesi.php" target="_blank" class="form-control">Üyelik ve Hizmet Sözleşmesi</a></strong> 'ni okudum ve kabul ediyorum.</label><br></td>
</div>
<br>
<div class="mt-1">
<button  type="submit" value="Kayıt ol">Hesabı Oluştur</button>
<p class="message mb-0 mt-1">Parolanızımı unuttunuz? <a href="sifremi-unuttum">parolanızı sıfırlayın !</a></p>
</div>
</form>
</div>
</div>