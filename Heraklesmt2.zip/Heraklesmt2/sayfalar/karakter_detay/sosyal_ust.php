<?php if(!defined("WM_HTML_KONTROL")){ die("Buraya giriş izniniz yoktur."); exit;} ?>

<a href="kullanici/karakterlerim?karakter_duzenle=<?=$fetch["id"];?>" class="prf_dznl"><img src="<?=$ayar->WMimg;?>edit.png"> Profilini Düzenle</a>

<div style="margin-bottom:20px"></div>
