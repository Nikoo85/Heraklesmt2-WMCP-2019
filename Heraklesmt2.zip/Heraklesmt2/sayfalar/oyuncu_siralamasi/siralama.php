<?php if(!defined("WM_HTML_KONTROL")){ die("Buraya giriş izniniz yoktur."); exit;} ?>

<div class="bg-light ranking">
                        <table>
                            <tbody>
                            <tr>
                                <th>#</th>
                                <th>İsim</th>
                                <th>Seviye</th>
                                <th>Bayrak</th>
                                <th>Lonca</th>
                                <th>Oyun Süresi</th>
                            </tr>
							
	<?php 
	$i = $limit;
	foreach($query as $row){
	$i++;
	?>
	
                             <tr>
                                <td><?=$i;?></td>
                                <td><a href="karakter/<?=$row["name"];?>"><?=$row["name"];?>  
								  <?php 
								  $goz_at = $db->prepare("Select id FROM onayli_karakter WHERE sid = ? && isim = ?");
								  $goz_at->execute(array(server, $row["name"]));
								  if($goz_at->rowCount()){ ?><img title="Onaylı Karakter" src="<?=$ayar->WMimg;?>onaylandi.png"></a></td><?php }
								  ?>
                                <td><?=$row["level"];?></td>
                                <td><img src="<?=$ayar->WMimg.'bayrak/'.$row["empire"];?>.png"></td>
                                <td>
                                                                    <a href="../detail/guild/Poppy.html"><?=($row["lonca"] == "") ? '<span style="color:red">Yok<span></span>' : '<a href="lonca/'.$row["lonca"].'">'.$row["lonca"].'</a>';?></a>
                                                                </td>
                                <td>29301</td>
                            </tr>
	
    
	<?php 
	}
	?>
							
                  </tbody>
                        </table>
                    </div>
					

<div class="sayfalar">
<?php

$tema->sayfala("oyuncu-siralamasi?isim=$isim&karakter=$karakter&sayfa=", $sayfa, $sayfada, $toplam_sayfa);

?>

</div>
