<?php if(!defined("WM_HTML_KONTROL")){ die("Buraya giriş izniniz yoktur."); exit;} ?>
<div class="content-block-info" style="display: block;">
<div class="news-block" style="width: 100%;">
<div class="content-title c-title">
<span class="title">Heraklesmt2'yi Şimdi İndir DARKMMO Türkiye'nin En İyi MMO Forumu</span>
<a onclick="$('#sistemozellikleri').slideToggle('normal');"> Sistem Gereksinimlerini Görüntüle</a>
</div>
<i ></i> Eğer bilgisayarınızda Metin2 yoksa Full Client indiriniz.
<div class="content-title c-title"></div><table class="download-table" border="0" style="font-size: 13px;width: 100% !important;">

<tbody>
<tr>
<td style="color: #74c564;">Full Client [DARKMMO.COM] </td>
<td>1.4GB</td>
<td style="vertical-align:middle;text-align:right;"><a href="http://www.darkmmo.com/bolum/metin2-pvp-panel-web.49/" target="_blank" class="blue-a green-a">TIKLA İNDİR!</a></td>
</tr>
<tr>
<td style="color: #74c564;">Full Client [DARKMMO.COM]</td>
<td>1.4GB</td>
<td style="vertical-align:middle;text-align:right;"><a href="http://www.darkmmo.com/bolum/metin2-pvp-panel-web.49/" target="_blank" class="blue-a green-a">TIKLA İNDİR!</a></td>
</tr>
<tr>
<td style="color: #74c564;">Full Client [DARKMMO.COM]</td>
<td>1.4GB</td>
<td style="vertical-align:middle;text-align:right;"><a href="http://www.darkmmo.com/bolum/metin2-pvp-panel-web.49/" target="_blank" class="blue-a green-a">TIKLA İNDİR!</a></td>
</tr>
</tbody>
</table>
</div>
</div>