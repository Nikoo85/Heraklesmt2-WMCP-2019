<?php

class server
{
	
public function lonca($limit = 5)
{
global $odb, $ayar;

$query = $odb->query("SELECT guild.name, player.name AS lider, player_index.empire AS bayrak, guild.level, guild.ladder_point,guild.id FROM player.guild
	LEFT JOIN player.player
	ON guild.master = player.id
	LEFT JOIN player.player_index
	ON player_index.id = player.account_id
	ORDER BY ladder_point DESC
	LIMIT 0, $limit");

$i = 0;

foreach($query as $row)
{
$i++;
?>


<div class="player-info">
<div class="top-number"><?=$i;?></div>
<div class="top-name"> <span><?=$row["name"];?></span> </div>
<div class="top-r">
<span><?=$row["ladder_point"];?></span> <a href="lonca-siralamasi" class="green-a profile-button">Sıralamayı Gör</a>
</div>
</div>


<?php	
}

}

public function karakter($limit = 5)
{
global $odb, $ayar, $db;

$query = $odb->query("SELECT player.id,player.name,player.job,player.level,player.exp,player_index.empire,guild.name AS guild_name 
	  FROM player.player 
	  LEFT JOIN player.player_index 
	  ON player_index.id=player.account_id 
	  LEFT JOIN player.guild_member 
	  ON guild_member.pid=player.id 
	  LEFT JOIN player.guild 
	  ON guild.id=guild_member.guild_id
	  INNER JOIN account.account 
	  ON account.id=player.account_id
	  WHERE player.name NOT LIKE '[%]%' AND account.status!='BLOCK' ORDER BY player.level DESC, player.playtime DESC LIMIT 0,$limit");

$i = 0;

foreach($query as $row)
{
$i++;
?>


<div class="player-info">
<div class="top-number"><?=$i;?></div>
<div class="top-name"> <span><?=$row["name"];?></span> </div>
<div class="top-r">
<span><?=$row["level"];?></span> <a href="oyuncu-siralamasi" class="green-a profile-button">Sıralama</a>
</div>
</div>





<?php	
}

}
	
}

?>