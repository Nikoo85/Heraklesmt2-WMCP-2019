<?php if(!defined("WM_HTML_KONTROL")){ die("Buraya giriş izniniz yoktur."); exit;} ?>




<div class="bg-dark">

                        <div class="col-50">
                            <a class="btn active" href="javascript:void(0);">Oyuncu Sıralaması</a>
                        </div>
                        <div class="col-50">
                            <a class="btn" href="lonca-siralamasi">Lonca Sıralaması</a>
                        </div>
                    </div>
	
</table>
