<?php if(!defined("WM_HTML_KONTROL")){ die("Buraya giriş izniniz yoktur."); exit;} ?>

<a href="lonca-siralamasi"><< Lonca Sıralamasına Dön</a>
