<?php 
require_once 'sayfalar/class.php';

$srv = new server;

?>
<!DOCTYPE html>
<html lang="tr">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<meta http-equiv="content-type" content="text/html;charset=latin-5" />
<head>
<meta charset="utf-8" />
<?php $wmcp->head(); ?>
<?php $tema->stiller(); ?>
<meta name="keywords" content="Heraklesmt2, herakles2, Heraklesmt2 1-120, 1-120 Farm server, metin2 pvp server, heraklesmt2 emek server, herakles mt2, m2pvp,herakles2pvpserver" /><meta name="description" content="Heraklesmt2 Resmi Web Sayfasıdır." />
<link href="<?=WM_tema;?>herakles2018/css/reset.css" rel="stylesheet">
<link href="<?=WM_tema;?>genel.css" rel="stylesheet">
<link href="<?=WM_tema;?>herakles2018/css/style.css" rel="stylesheet">
<link href="<?=WM_tema;?>herakles2018/css/global.css" rel="stylesheet">
<link href="<?=WM_tema;?>herakles2018/css/util.css" rel="stylesheet">
<link href="<?=WM_tema;?>herakles2018/css/small-page.css" rel="stylesheet">
<link href="<?=WM_tema;?>herakles2018/css/animate.min.css" rel="stylesheet">
<link href="<?=WM_tema;?>herakles2018/lib/fancybox3/jquery.fancybox.min.css" rel="stylesheet">
<link href="<?=WM_tema;?>herakles2018/fonts/fontawesome/fontawesome-combined.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="<?=WM_tema;?>herakles2018/uyari/sweetalert.css">
<script src="<?=WM_tema;?>herakles2018/uyari/sweetalert.min.js"></script>
<link rel="icon" href="<?=WM_tema;?>herakles2018/favicon.png" type="image/x-icon" />
<script src="<?=WM_tema;?>herakles2018/js/jquery-2.1.4.min.js"></script>
<script src="<?=WM_tema;?>herakles2018/lib/jquery/jquery.min.js"></script>
<script src="<?=WM_tema;?>herakles2018/lib/fancybox3/jquery.fancybox.min.js"></script>
<script src="<?=WM_tema;?>herakles2018/js/slider.js"></script>
<script src="<?=WM_tema;?>herakles2018/js/modalx.js"></script>
<script src="<?=WM_tema;?>js/global.js"></script>
</head>
<body>
<div id="sonuc"></div>
<div class="wrapper">
<header class="header">
<div class="menu-top">
<ul class="menu-top-left">
<li>
<a href="index.php">ANASAYFA</a>
</li>
<?php if(!isset($_SESSION[$vt->a("isim")."token"])){ ?>
<li>
<a href="kaydol">KAYIT OL</a>
</li>
<?php }else{ ?>
<li>
<a href="kaydol">HESABIM</a>
</li>
<?php } ?>
<li class="">
<a href="oyunu-indir">İNDİR</a>
</li>
</ul>
<ul class="menu-top-right">
<li>
</li>
<li>
<a href="http://www.darkmmo.com/bolum/metin2-pvp-panel-web.49/" target="_blank">FORUM</a>
</li>
<li>
<a href="http://www.darkmmo.com/bolum/metin2-pvp-panel-web.49/">DESTEK</a>
</li>
<li>
<a href="http://www.darkmmo.com/bolum/metin2-pvp-panel-web.49/" target="_blank" style="color: #efbe24;">TANITIM</a>
</li>
</ul>
<div class="server-load">
<div>AKTİF<br> OYUNCU</div>
<span id="online_oyuncu">
ERROR </span>
</div>
</div>
</header>
<div class="container">
<main class="content">
<div class="top-content-block">
<div class="download-bonus-block">
<div class="download">
<a href="oyunu-indir"></a>
</div>
<div class="bonus-block">
<a href="https://www.darkmmo.com/bolum/metin2-pvp-panel-web.49/" target="_blank" class="bonus">
&nbsp;
</a>
<a href="#" class="facebook">
&nbsp;
</a>
<a href="#" target="_blank" class="support">
&nbsp;
</a>
<a href="#" class="shop">
&nbsp;
</a>
</div>
</div>
<div class="slider">
<div class="next"> </div>
<div class="prev"> </div>
<div class="slides">
<div class="slide active">
<h2>DARKMMO</h2>
<p>Türkiye'nin En İyi MMO FORUMU</p>
<img src="<?=WM_tema;?>herakles2018/images/slider/sl_3.jpg" alt="">
<div>
<a href="#" target="_blank">DARKMMO</a>
<span>Duyuru Gelecek</span>
</div>
</div>
<div class="slide">
<img src="<?=WM_tema;?>herakles2018/images/slider/sl_2.jpg" alt="">
<h2>DARKMMO</h2>
<p>Türkiye'nin En İyi MMO FORUMU</p>
<div>
<a href="http://www.heraklesmt2.com" target="_blank">DARKMMO</a>
<span>Duyuru Gelecek</span>
</div>
</div>
<div class="slide">
<h2>DARKMMO</h2>
<p>Türkiye'nin En İyi MMO FORUMU</p>
<img src="<?=WM_tema;?>herakles2018/images/slider/sl_1.jpg" alt="">
<div>
<a href="http://www.heraklesmt2.com" target="_blank">DARKMMO</a>
<span>Duyuru Gelecek</span>
</div>
</div>
</div>
<div class="navigation"></div>
</div>
</div>
<div align=""> <?=$wmcp->orta();?>    </div> 
</main>
<aside class="sidebar">
<div class="shop-block">
<div class="shop ninja">
<p>DARKMMO FORUM</p>
<span>Türkiye'nin En İyi MMO Forumu</span>
<a href="https://www.darkmmo.com/bolum/metin2-pvp-panel-web.49/" class="blue-a">SİTEYE GİT</a>
</div>
<div class="shop sura">
<p>EN İYİ OYUNCULAR</p>
<span>EN İYİ OYUNCULARIN SIRALAMASI</span>
<a href="/oyuncu-siralama" class="blue-a green-a">OYUNCU SIRALAMASINA GİT</a>
</div>
<div class="shop shaman">
<p>EN İYİ LONCALAR</p>
<span>EN İYİ LONCALARIN SIRALAMASI</span>
<a href="/lonca-siralama" class="gold-a">LONCA SIRALAMASINA GİT</a>
</div>
</div>
<div class="login-block">
<div class="login-block-b">
<?php if(!isset($_SESSION[$vt->a("isim")."token"])){ ?>
<form id="giris" class="login-form block-p" action="javascript:;" accept-charset="UTF-8" method="post">
<div class="login-title">
<span>VEYA &nbsp;&nbsp;<a href="kaydol">KAYIT OL</a></span>GİRİŞ YAP
</div>
</br>
<input type="hidden" name="giris_csrf_token" value="<?=$ayar->sessionid;?>" />
<input type="hidden" value="<?=$ayar->sessionid;?>" name="giris_token" />
<p><input type="text" name="username" id="HesapAdiInput" value="" maxlength="16" autocomplete="off" placeholder="Hesap ID"></p>
<p><input type="password" name="pass" value="" maxlength="24" placeholder="Parola"></p>

<input type="hidden" name="post" value="login_account" />
<button type="submit" name="login-submit">GİRİŞ YAP</button>
<a href="sifremi-unuttum" class="lost-pass">Parolamı unuttum.</a>
</form>
<?php }else{ ?>
<div class="lk-form block-l">
<div id="sonuc_cikis"></div>
<br>
<div class="lk-title">
<a onclick="#" class="top-up-btn gold-a">YÜKLE</a>
<span class="coins"><?=$vt->uye("coins");?> EP</span>
<span class="username"><?=$_SESSION[$vt->a("isim")."username"];?></span>
<span class="userdetail">Darkmmo Türkiye'nin En İyi MMO Platformu</span>
</div>
<ul>
<li><a href="kullanici">Hesabım</a></li>

<li><a href="cikis-yap">Çıkış Yap</a></li>
</li>
</ul>
</div>
<?php } ?>
</div>
</div>
<div class="best-players">
<div class="sidebar-title best-players-title">
EN İYİ OYUNCULAR <span>EN İYİ<b>5</b></span>
</div>
<div class="top-players block-p block-bt">
<?=$srv->karakter(5);?>

<br><center><span>Her 1 Saate Bir Güncellenir</span></center>
</div>
</div>
<div class="best-guilds">
<div class="sidebar-title best-guilds-title"> EN İYİ LONCALAR <span>EN İYİ<b>5</b></span> </div>
<div class="top-players block-p">
<?=$srv->lonca(5);?>
<br><center><span>Her 1 Saate Bir Güncellenir</span></center>
</div>
</div>
</aside>
</div>
<footer class="footer">
<div class="footer-links-block">
<div class="footer-links-block-i">
<div class="footer-top">
<div class="footer-logo">
<a href="/anasayfa"></a>
</div>
<div class="footer-s">
<span>
<a href="oyuncu-siralama">Oyuncu Sıralaması</a>
</span>
<span>
<a href="lonca-siralama">Lonca Sıralaması</a>
</span>
<span>
<a href="http://www.darkmmo.com/bolum/metin2-pvp-panel-web.49/">DARKMMO</a>
</span>
<span>
<a href="#" target="_blank">Ejderha Parası Satın Al</a>
</span>
<span>
<a href="#">Hizmet Şartları</a>
</span>
<span>
<a href="#">Gizlilik Sözleşmesi</a>
</span>
<span>
<a href="oyunu-indir">İndir</a>
</span>
<?php if(!isset($_SESSION[$vt->a("isim")."token"])){ ?>
<span>
<a href="kaydol">Kayıt Ol</a>
</span>
<?php }else{ ?>
<span>
<a href="kullanici">HESABIM</a>
</span>
<?php } ?>
</div>
</div>
</div>
</div>
<div class="footer-nav">
<div class="soc-links">
<a href="http://www.darkmmo.com/bolum/metin2-pvp-panel-web.49/" target="_blank" class="facebook"></a>
<a href="http://www.darkmmo.com/bolum/metin2-pvp-panel-web.49/" target="_blank" class="inst"></a>
<a href="http://www.darkmmo.com/bolum/metin2-pvp-panel-web.49/" target="_blank" class="twitter"></a>
</div>
<div class="banner">
<a href="http://www.darkmmo.com/bolum/metin2-pvp-panel-web.49/"><img src="<?=WM_tema;?>herakles2018/images/darkmmo.png" alt=""></a>
</div>
<div class="f-menu">
<ul>
<li><a href="index.php">Anasayfa</a></li>
<li><a href="oyunu-indir">İndir</a></li>
<li><a href="kaydol">Kayıt Ol</a></li>
<li><a href="http://www.darkmmo.com/bolum/metin2-pvp-panel-web.49/" target="_blank">Forum</a></li>
<li><a href="http://www.darkmmo.com/bolum/metin2-pvp-panel-web.49/" target="_blank">Destek</a></li>
<li><a href="http://www.darkmmo.com/bolum/metin2-pvp-panel-web.49/" target="_blank">Tanıtım</a></li>
</ul>
</div>
</div>
<div class="footer-info">
<div class="terms">
&copy; HeraklesMT2 2019 Darkmmo Furkan Çelebi Gkanos / Nikoo85</br>
<center><img src="<?=WM_tema;?>herakles2018/images/darkmmo.png"></center>
</div>
<div class="copyright">
HeraklesMT2 2019 Darkmmo Furkan Çelebi Gkanos / Nikoo85 tarafından sağlanmaktadır.
</div>
<div id="toTop"></div>
</div>

</footer>
</div>
<?php 
$tema->jquery($konum); 

?>
</body>
</html>
